export interface User {
  name: string;
  address: {
    street: string;
    postcode: string;
  }
}