export * from './capitalize.pipe';
export * from './page-global-pipe.component';