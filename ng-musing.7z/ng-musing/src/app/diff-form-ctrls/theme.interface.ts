export interface Theme {
  display: string;
  backgroundColor: string;
  fontColor: string;
}