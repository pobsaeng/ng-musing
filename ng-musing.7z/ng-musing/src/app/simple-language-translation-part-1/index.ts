export * from './translate-1.pipe';
export * from './translate-1.service';
export * from './translations-1';
export * from './page-simple-language-translation-part-1.component';