// lang-es.ts

export const LANG_ES_NAME = 'es';

export const LANG_ES_TRANS = {
    'hello world': 'hola mundo',
    'hello greet': 'Hola, %0 %1!',
    'well done': '%0 bien hecho',
};