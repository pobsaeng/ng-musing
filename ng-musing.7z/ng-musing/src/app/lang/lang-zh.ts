// lang-zh.ts

export const LANG_ZH_NAME = 'zh';

export const LANG_ZH_TRANS = {
    'hello world': '你好，世界',
    'hello greet': '你好, %0 %1!',
    'well done': '干得好, %0',
};