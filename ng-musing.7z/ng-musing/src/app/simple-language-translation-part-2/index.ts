export * from './translate-2.pipe';
export * from './translate-2.service';
export * from './translations-2';
export * from './page-simple-language-translation-part-2.component';