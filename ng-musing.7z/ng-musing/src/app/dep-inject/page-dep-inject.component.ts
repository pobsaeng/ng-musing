import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'page-dep-inject',
    templateUrl: './page-dep-inject.component.html'
})
export class PageDepInjectComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}