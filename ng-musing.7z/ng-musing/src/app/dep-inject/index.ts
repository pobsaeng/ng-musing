export * from './dep-a.service';
export * from './dep-b.service';
export * from './dep-ctn.component';
export * from './dep-inject.component';
export * from './page-dep-inject.component';